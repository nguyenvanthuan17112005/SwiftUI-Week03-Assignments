import SwiftUI
enum PaymentMethod: String, CaseIterable, Identifiable {
    case paypal = "PayPal"
    case googlePay = "GooglePay"
    case applePay = "ApplePay"
    
    var id: String { rawValue }
    var icon: String{
        switch self{
        case .paypal: return "paypal"
        case .googlePay: return "googlePay"
        case .applePay: return "applePay"
        }
    }
    var logoImage: Image{
        switch self{
        case .paypal:
            return Image("paypal_logo.png")
        case .googlePay:
            return Image("googlePay_logo.png")
        case .applePay:
            return Image("applePay_logo.png")
        }
    }
}
