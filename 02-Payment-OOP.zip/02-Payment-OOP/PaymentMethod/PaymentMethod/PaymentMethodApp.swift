//
//  PaymentMethodApp.swift
//  PaymentMethod
//
//  Created by Nguyễn Văn Thuận on 22/12/25.
//

import SwiftUI

@main
struct PaymentMethodApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
           
        }
    }
}
